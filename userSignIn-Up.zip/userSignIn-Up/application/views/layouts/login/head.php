<link rel="icon" href="{ASSET_INCLUDE_URL}images/favicon.ico" type="image/x-icon" />
<link rel="shortcut icon" type="{ASSET_INCLUDE_URL}image/x-icon" href="images/favicon.png" />
<!--Link CSS File-->
<!-- Font Icon -->
<link rel="stylesheet" href="{ASSET_INCLUDE_URL}fonts/material-icon/css/material-design-iconic-font.min.css">

<!-- Main css -->
<link rel="stylesheet" href="{ASSET_INCLUDE_URL}css/style.css">
<link rel="stylesheet" href="{ASSET_INCLUDE_URL}css/teju.css">
<link rel="stylesheet" href="{ASSET_INCLUDE_URL}css/alerts.css">
<script type="text/ecmascript">
var BASEURL 			=	'{BASE_URL}';
var FULLSITEURL 		=	'{FULL_SITE_URL}';
var ASSETURL 			=	'{ASSET_URL}';
var ASSETINCLUDEURL 	=	'{ASSET_INCLUDE_URL}';
var CURRENTCLASS 		=	'{CURRENT_CLASS}';
var CURRENTMETHOD 		=	'{CURRENT_METHOD}';
var csrf_api_key		=	'<?php echo $this->security->get_csrf_token_name(); ?>';
var csrf_api_value 		=	'<?php echo $this->security->get_csrf_hash(); ?>'; 
</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script type="text/javascript">
	var searchPageShow   =  'No';
</script>