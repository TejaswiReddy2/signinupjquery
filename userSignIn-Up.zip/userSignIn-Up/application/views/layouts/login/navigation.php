<!-- Wrapper -->

<div id="loading-area"></div>

<div class="page-wraper">



<!-- Header Container

================================================== -->

<header class="site-header mo-left header fullwidth">

        <!-- main header -->

        <div class="sticky-header main-bar-wraper navbar-expand-lg">

            <div class="main-bar clearfix">

                <div class="container clearfix">

                    <!-- website logo -->

                    <div class="logo-header mostion">

                        <a href="{BASE_URL}"><img src="{ASSET_INCLUDE_URL}images/logo.png" class="logo" alt=""></a>

                    </div>

                    <!-- nav toggle button -->

                    <!-- nav toggle button -->

                    <button class="navbar-toggler collapsed navicon justify-content-end" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">

                        <span></span>

                        <span></span>

                        <span></span>

                    </button>

                    <!-- extra nav -->

                    <div class="extra-nav">

                        <div class="extra-cell">

                            <a href="{BASE_URL}sign-up/" class="site-button"><i class="fa fa-user"></i> Sign Up</a>

                            <a href="{BASE_URL}login/" title="READ MORE" rel="bookmark" class="site-button"><i class="fa fa-lock"></i> login </a>

                        </div>

                    </div>

                    <!-- main nav -->

                    <div class="header-nav navbar-collapse collapse justify-content-start" id="navbarNavDropdown">

                        <ul class="nav navbar-nav">

                            <li class="active">

                                <a href="{BASE_URL}">Home</a></li>

                            

                            <li>

                                <a href="#">Employers</a></li>

                            <li>

                            <li>

                                <a href="#">Post A Job</a></li>

                            

                        </ul>           

                    </div>

                </div>

            </div>

        </div>

        <!-- main header END -->

    </header> 

<div class="clearfix"></div>

<!-- Header Container / End -->